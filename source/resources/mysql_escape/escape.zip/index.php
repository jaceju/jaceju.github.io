<?php
//===============================================
// ���J�{��
//===============================================
require_once 'config.php';
require_once 'class/MySQL.php';
require_once 'Smarty/Smarty.class.php';
require_once 'class/Request.php';

//===============================================
// ���o�Ѽ�
//===============================================
$request = new Request('REQUEST');
$title = $request->getValue('title', 'string', '');
$keyword = $request->getValue('keyword', 'string', '');
$search_type = $request->getValue('search_type', 'string', 'like');

//===============================================
// �s����Ʈw
//===============================================
$db = MySQL::connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_CHAR_SET);

//===============================================
// Insert
//===============================================
$insert = '';
if ($title != '')
{
    $insert = sprintf("INSERT INTO %s (title) VALUES ('%s')", TABLE_NAME, $db->escape($title));

    $db->query($insert);
}

//===============================================
// Query
//===============================================
$recordset = array();
if ($keyword != '')
{
    $search_keyword = ('like' == $search_type) ?
        '%' . $db->searchEscape($keyword) . '%' :
        $db->escape($keyword);
        
    $query = ('like' == $search_type) ?
        sprintf("SELECT * FROM %s WHERE title LIKE '%s' ORDER BY id DESC LIMIT 10", TABLE_NAME, $search_keyword) :
        sprintf("SELECT * FROM %s WHERE title = '%s' ORDER BY id DESC LIMIT 10", TABLE_NAME, $search_keyword);
}
else
{
    $query = sprintf("SELECT * FROM %s ORDER BY id DESC LIMIT 10", TABLE_NAME);
}
$result = $db->query($query);

while ($row = $result->fetchAssoc())
{
    $recordset[] = $row;
}
$result->free();

//===============================================
// ���覡
//===============================================
$search_types = array (
    'like' => '�������',
    'full' => '������',
);

//===============================================
// �˪�
//===============================================
$smarty = new Smarty();

//===============================================
// �˪��ܼ�
//===============================================
$smarty->assign('db', $db);
$smarty->assign('recordset', $recordset);
$smarty->assign('title', $title);
$smarty->assign('query', $query);
$smarty->assign('keyword', $keyword);
$smarty->assign('insert', $insert);
$smarty->assign('search_types', $search_types);
$smarty->assign('search_type', $search_type);

//===============================================
// ��ܼ˪�
//===============================================
$smarty->display('index.tpl.htm')

?>
