<?php
//===============================================
// 載入程式
//===============================================
require_once 'config_utf8.php';
require_once 'class/MySQLWrapper.php';
require_once 'DB.php';
require_once 'Smarty/Smarty.class.php';
require_once 'class/Request.php';

//===============================================
// 取得參數
//===============================================
$request = new Request('REQUEST');
$title = $request->getValue('title', 'html', '');
$keyword = $request->getValue('keyword', 'html', '');
$search_type = $request->getValue('search_type', 'string', 'like');

//===============================================
// 連結資料庫
//===============================================
$db = &DB::connect(DB_DSN);
if (DB::isError($db))
{
    header("Content-Type: text/html; charset=utf-8");
    die ($db->getDebugInfo());
}
$db = new MySQLWrapper($db, DB_CHAR_SET);
$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// Insert
//===============================================
$insert = '';
if ($title != '')
{
    $insert = &$db->prepare("INSERT INTO " . TABLE_NAME . "(title) VALUES (?)");
    $result = &$db->execute($insert, array ($title));
    if (DB::isError($result))
    {
        header("Content-Type: text/html; charset=utf-8");
        die ($result->getDebugInfo());
    }
}

//===============================================
// Query
//===============================================
$recordset = array();
if ($keyword != '')
{
    $search_keyword = ('like' == $search_type) ?
        '%' . $db->searchEscape($keyword) . '%' :
        $keyword;

    $query = ('like' == $search_type) ?
        sprintf("SELECT * FROM %s WHERE title LIKE ? ORDER BY id DESC LIMIT 10", TABLE_NAME, $search_keyword) :
        sprintf("SELECT * FROM %s WHERE title = ? ORDER BY id DESC LIMIT 10", TABLE_NAME, $search_keyword);

    $recordset = &$db->getAll($query, array($search_keyword));
}
else
{
    $query = "SELECT * FROM " . TABLE_NAME . " ORDER BY id DESC LIMIT 10";
    $recordset = &$db->getAll($query);
}

if (DB::isError($recordset))
{
    header("Content-Type: text/html; charset=big5");
    die ($recordset->getUserInfo());
}

//===============================================
// 比對方式
//===============================================
$search_types = array (
    'like' => '部份比對',
    'full' => '完整比對',
);

//===============================================
// 樣版
//===============================================
$smarty = new Smarty();

//===============================================
// 樣版變數
//===============================================
$smarty->assign('db', $db);
$smarty->assign('recordset', $recordset);
$smarty->assign('title', $title);
$smarty->assign('keyword', $keyword);
$smarty->assign('insert', $insert);
$smarty->assign('search_types', $search_types);
$smarty->assign('search_type', $search_type);

//===============================================
// 顯示樣版
//===============================================
$smarty->display('index_utf8.tpl.htm')

?>
