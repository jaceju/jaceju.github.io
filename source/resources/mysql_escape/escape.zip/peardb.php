<?php
//===============================================
// ���J�{��
//===============================================
require_once 'config.php';
require_once 'class/PEARDBWrapper.php';
require_once 'DB.php';
require_once 'Smarty/Smarty.class.php';
require_once 'class/Request.php';

//===============================================
// ���o�Ѽ�
//===============================================
$request = new Request('REQUEST');
$title = $request->getValue('title', 'string', '');
$keyword = $request->getValue('keyword', 'string', '');
$search_type = $request->getValue('search_type', 'string', 'like');

//===============================================
// �s����Ʈw
//===============================================
$db = &DB::connect(DB_DSN);
if (DB::isError($db))
{
    header("Content-Type: text/html; charset=big5");
    die ($db->getDebugInfo());
}
$db = new PEARDBWrapper($db, DB_CHAR_SET);
$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// Insert
//===============================================
$insert = '';
if ($title != '')
{
    $insert = sprintf("INSERT INTO %s (title) VALUES (?)", TABLE_NAME);
    $sth = &$db->prepare($insert);
    $result = &$db->execute($sth, array ($title));
    if (DB::isError($result))
    {
        header("Content-Type: text/html; charset=big5");
        die ($result->getDebugInfo());
    }
}

//===============================================
// Query
//===============================================
$recordset = array();
if ($keyword != '')
{
    $search_keyword = ('like' == $search_type) ?
        '%' . $db->searchEscape($keyword) . '%' :
        $keyword;

    $query = ('like' == $search_type) ?
        sprintf("SELECT * FROM %s WHERE title LIKE ? ORDER BY id DESC LIMIT 10", TABLE_NAME) :
        sprintf("SELECT * FROM %s WHERE title = ? ORDER BY id DESC LIMIT 10", TABLE_NAME);

    $recordset = &$db->getAll($query, array($search_keyword));
}
else
{
    $query = sprintf("SELECT * FROM %s ORDER BY id DESC LIMIT 10", TABLE_NAME);
    $recordset = &$db->getAll($query);
}

if (DB::isError($recordset))
{
    header("Content-Type: text/html; charset=big5");
    die ($recordset->getUserInfo());
}

//===============================================
// ���覡
//===============================================
$search_types = array (
    'like' => '�������',
    'full' => '������',
);

//===============================================
// �˪�
//===============================================
$smarty = new Smarty();

//===============================================
// �˪��ܼ�
//===============================================
$smarty->assign('db', $db);
$smarty->assign('recordset', $recordset);
$smarty->assign('title', $title);
$smarty->assign('keyword', $keyword);
$smarty->assign('query', $query);
$smarty->assign('insert', $insert);
$smarty->assign('search_types', $search_types);
$smarty->assign('search_type', $search_type);

//===============================================
// ��ܼ˪�
//===============================================
$smarty->display('index.tpl.htm')

?>
