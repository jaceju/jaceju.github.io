-- phpMyAdmin SQL Dump
-- version 2.8.2
-- http://www.phpmyadmin.net
-- 
-- 主機: localhost
-- 建立日期: Jul 09, 2006, 04:53 PM
-- 伺服器版本: 4.0.27
-- PHP 版本: 5.1.4
-- 
-- 資料庫: `test`
-- 
DROP DATABASE IF EXISTS `test`;
CREATE DATABASE `test`;
USE `test`;

-- --------------------------------------------------------

-- 
-- 資料表格式： `big5`
-- 

DROP TABLE IF EXISTS `big5`;
CREATE TABLE IF NOT EXISTS `big5` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `title` (`title`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

-- 
-- 資料表格式： `utf8`
-- 

DROP TABLE IF EXISTS `utf8`;
CREATE TABLE IF NOT EXISTS `utf8` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `title` (`title`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;
