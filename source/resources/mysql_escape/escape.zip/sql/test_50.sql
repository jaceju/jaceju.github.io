-- phpMyAdmin SQL Dump
-- version 2.8.1
-- http://www.phpmyadmin.net
-- 
-- 主機: localhost
-- 建立日期: Jul 10, 2006, 02:41 AM
-- 伺服器版本: 5.0.22
-- PHP 版本: 5.1.2
-- 
-- 資料庫: `test`
-- 
DROP DATABASE IF EXISTS `test`;
CREATE DATABASE `test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `test`;

-- --------------------------------------------------------

-- 
-- 資料表格式： `big5`
-- 

DROP TABLE IF EXISTS `big5`;
CREATE TABLE IF NOT EXISTS `big5` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=big5;

-- --------------------------------------------------------

-- 
-- 資料表格式： `utf8`
-- 

DROP TABLE IF EXISTS `utf8`;
CREATE TABLE IF NOT EXISTS `utf8` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
