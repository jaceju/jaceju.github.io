<?php
class Request
{

    var $_apply_type = array ('REQUEST', 'POST', 'GET');
    
    var $_values = array ();

    function Request($type = 'POST')
    {
        $type = strtoupper($type);
        if (!in_array($type, $this->_apply_type)) $type = 'POST';
        eval ('$this->_values = &$_' . $type . ';');

        if (get_magic_quotes_gpc())
        {
            $this->_values = $this->_array_map_recursive('stripslashes', $this->_values);
        }
    }
    
    function getValue($name, $type = 'string', $default_value = NULL)
    {
        $value = isset ($this->_values[$name]) ?
            $this->_values[$name] :
            $default_value;

        switch (strtolower($type))
        {
            case 'int':
            case 'long':
                $value = (int) $value;
                break;
            case 'float':
                $value = (float) $value;
                break;
            case 'date':
            case 'string':
                $value = (string) $value;
                break;
            case 'html':
            default:
                $value = htmlspecialchars($value);
                break;
        }
        
        return $value;
        
    }

    /* �Ϊk�G
    * $a = array (1, 2, 3, 4, 5);
    * $a = array_map_recursive('function_name', $a); // callback function
    * $a = array_map_recursive(array ('class_name', 'class_method'), $a); // callback static class method
    * $a = array_map_recursive(array (& $object, 'object_method'), $a); // callback object method
    */
    function _array_map_recursive($func, $arr)
    {
        $result = array();
        foreach ($arr as $key => $value)
        {
            if (is_array($value))
            {
                $result[$key] = $this->_array_map_recursive($func, $value);
            }
            else
            {
                if (is_array($func))
                {
                    if (is_object($func[0]))
                    $result[$key] = $func[0]->$func[1]($value);
                    if (is_string($func[0]))
                    eval('$result[$key] = ' . $func[0] . '::' . $func[1] . '($value);');
                }
                else
                {
                    $result[$key] = $func($value);
                }
            }
        }
        return $result;
    }

}
?>
