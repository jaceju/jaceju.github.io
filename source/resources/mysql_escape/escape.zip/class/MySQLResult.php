<?php
class MySQLResult
{
    var $_result = NULL;

    function MySQLResult($result)
    {
        $this->_result = $result;
    }

    function fetchAssoc()
    {
        return mysql_fetch_assoc($this->_result);
    }

    function free()
    {
        if (is_resource($this->_result)) mysql_free_result($this->_result);
    }

}
?>