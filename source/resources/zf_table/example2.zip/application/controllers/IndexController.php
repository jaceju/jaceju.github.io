<?php

class IndexController extends Zend_Controller_Action 
{
    function indexAction()
    {
        $categories = new Categories();
        $articles   = new Articles();
        $tags       = new Tags();

        // 主分類對次分類 (一對多)
        $php = $categories->find(1)->current();
        $this->view->subcategories = $php->findDependentRowset('Categories');

        // 分類對文章 (一對多)
        $zendframework = $categories->find(3)->current();
        $this->view->articles = $zendframework->findDependentRowset('Articles');

        // 文章對分類 (一對一)
        $phpArticle = $articles->find(2)->current();
        $this->view->category = $phpArticle->findParentRow('Categories');

        /* 也可以用以下的方式：
        $this->view->category = $phpArticle->findParentCategories;
        */

        // 文章對標籤 (多對多)
        $this->view->articleTags = $phpArticle->findManyToManyRowset('Tags', 'ArticlesTags', 'Article');
    }
}