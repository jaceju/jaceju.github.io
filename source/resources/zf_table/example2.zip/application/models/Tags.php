<?php

class Tags extends Zend_Db_Table_Abstract
{
    protected $_name = 'tags';
}
