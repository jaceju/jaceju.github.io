<?php
/**
 * Wacow Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Wacow
 * @package    Wacow_View
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id$
 */

/**
 * 
 *
 * @package    Wacow_View
 * @subpackage Wacow_View_Helper
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Wacow_View_Helper_Weblet extends Zend_View_Helper_Abstract
{
    /**
     * 顯示 Weblet
     *
     * @param string $name
     * @return string
     */
    public function weblet($name, $id = null)
    {
        if (null === $id) {
            $id = $name;
        }
        $broker = Wacow_Weblet_Broker::getInstance();
        $weblet = $broker->getWeblet($id);
        if (null === $weblet) {
            $weblet = $broker->createWeblet($name, $id);
            if ($weblet && !$weblet->isExecuted()) {
                $weblet->execute();
            }
        }
        return $weblet ? $weblet->render() : '';
    }
}