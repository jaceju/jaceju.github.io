<?php
/**
 * Wacow Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Wacow
 * @package    Wacow_Controller
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id$
 */

/**
 * @see Zend_Controller_Plugin_Abstract
 */
require_once 'Zend/Controller/Plugin/Abstract.php';

/**
 * 管理 Weblet
 *
 * @package    Wacow_Controller
 * @subpackage Wacow_Controller_Plugin
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Wacow_Controller_Plugin_Weblet extends Zend_Controller_Plugin_Abstract
{
    /**
     * Weblet
     *
     * @var Wacow_Weblet_Abstract
     */
    protected $_weblet = null;

    /**
     * 載入 Weblet
     *
     * @param Zend_Controller_Request_Abstract $request
     */
    public function dispatchLoopStartup(Zend_Controller_Request_Abstract $request)
    {
        $this->_executeWeblet($request);
        if ($this->_isWebletAjaxBack($request)) {
            $request->setControllerName('virtual-weblet');
            $request->setActionName('index');
        }
    }

    /**
     * 執行 Weblet
     *
     */
    protected function _executeWeblet(Zend_Controller_Request_Abstract $request)
    {
        $this->_weblet = $this->_getWeblet($request);
        if ((bool) $this->_weblet && !$this->_weblet->isExecuted()) {
            $this->_weblet->execute();
        }
    }

    /**
     * 取得 Weblet
     *
     * @return Wacow_Weblet_Abstract
     */
    protected function _getWeblet(Zend_Controller_Request_Abstract $request)
    {
        $unprocessedInfo = (array) $request->getParam('weblet');
        $broker = Wacow_Weblet_Broker::getInstance();
        return $broker->loadWebletFromUnprocessInfo($unprocessedInfo);
    }

    /**
     * 處理 Render
     *
     * @param Zend_Controller_Request_Abstract $request
     */
    public function dispatchLoopShutdown()
    {
        $request = $this->getRequest();
        if ($this->_isWebletAjaxBack($request)) {
            $this->getResponse()->setBody($this->_weblet->render());
        }
    }

    /**
     * 是否為 Weblet 的 Ajax 回傳
     *
     * @return bool
     */
    protected function _isWebletAjaxBack(Zend_Controller_Request_Abstract $request)
    {
        return ((bool) $this->_weblet && $request->isXmlHttpRequest());
    }
}

/**
 * 虛擬的 Weblet Controller
 *
 * @package    Wacow_Controller
 * @subpackage Wacow_Controller_Plugin
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class VirtualWebletController extends Zend_Controller_Action
{
    /**
     * 預設動作
     * 
     */
    public function indexAction()
    {
        if ($this->_helper->hasHelper('layout')) {
            $this->getHelper('layout')->disableLayout();
        }

        $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('ViewRenderer');
        /* @var $viewRenderer Zend_Controller_Action_Helper_ViewRenderer */
        if ($viewRenderer) { $viewRenderer->setNeverRender(true); }
    }
}