<?php

/**
 * Wacow Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Wacow
 * @package    Wacow_Weblet
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id$
 */

/**
 * 抽象 Weblet 類別
 *
 * @package    Wacow_Weblet
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
abstract class Wacow_Weblet_Abstract
{
    /**
     * 前端頁面識別用 ID
     *
     * @var string
     */
    protected $_id = null;

    /**
     * 設定前端頁面識別用 ID
     *
     * @param string $value
     */
    public function setId($value)
    {
        $this->_id = $value;
    }

    /**
     * Weblet 名稱
     *
     * @var string
     */
    protected $_name = null;

    /**
     * 取得 Weblet 名稱
     *
     * @return string
     */
    public function getName()
    {
        if ('' === trim($this->_name)) {
            $this->_name = $this->_getNameFormClassName();
        }
        return $this->_name;
    }

    /**
     * 從類別轉換名稱
     *
     * @return string
     */
    protected function _getNameFormClassName()
    {
        $className = get_class($this);
        $className = trim(substr($className, strrpos($className, '_')), '_');
        preg_match_all('/[A-Z]*[^A-Z]+/', $className, $matches);
        $tokens = $matches[0];
        return implode('-', array_map('strtolower', $tokens));
    }

    /**
     * View Script 副檔名
     *
     * @var string
     */
    protected $_viewSuffix = 'phtml';

    /**
     * 動作
     *
     * @var string
     */
    protected $_action = 'default';

    /**
     * 輸出格式
     *
     * @var string
     */
    protected $_format = 'html';

    /**
     * 設定 Format
     *
     * @param type $value
     */
    public function setFormat($value)
    {
        $value = strtolower(trim($value));
        if (in_array($value, array_keys($this->getAcceptedFormats()))) {
            $this->_format = strtolower($value);
        }
    }

    /**
     * 取得 Format
     *
     * @return string
     */
    public function getFormat()
    {
        return $this->_format;
    }

    /**
     * 接受的輸出格式
     *
     * @var array
     */
    protected $_acceptedFormats = array(
        'html' => null,
        'json' => null,
    );

    /**
     * 註冊輸出格式
     *
     * @param string $format
     * @param callback $callback
     */
    public function registerFormat($format, $callback = null)
    {
        $this->_acceptedFormats[strtolower($format)] = $callback;
    }

    /**
     * 取得接受的輸出格式
     *
     * @return array
     */
    public function getAcceptedFormats()
    {
        return $this->_acceptedFormats;
    }

    /**
     * GUID
     *
     * @var string
     */
    protected $_guid = '';

    /**
     * 設定 GUID
     *
     * @param string $value
     */
    public function setGuid($guid)
    {
        $this->_guid = $guid;
    }

    /**
     * 取得 GUID
     *
     * @return string
     */
    public function getGuid()
    {
        return $this->_guid;
    }

    /**
     * 建構
     *
     */
    public function __construct()
    {
        $this->_guid = $this->_buildUUID();
    }

    /**
     * 建立 GUID
     *
     * @return string
     */
    protected function _buildUUID()
    {
        // version 4 UUID
        return sprintf(
            '%08x-%04x-%04x-%02x%02x-%012x',
            mt_rand(),
            mt_rand(0, 65535),
            bindec(substr_replace(
                sprintf('%016b', mt_rand(0, 65535)), '0100', 11, 4)
            ),
            bindec(substr_replace(sprintf('%08b', mt_rand(0, 255)), '01', 5, 2)),
            mt_rand(0, 255),
            mt_rand()
        );
    }

    /**
     * 設置選項
     *
     * @param array $options
     * @return Wacow_Weblet_Abstract
     */
    public function setOptions($options)
    {
        foreach ($options as $key => $value) {
            switch ($key) {
                case 'view':
                    $this->setView($value);
                    break;
                case 'id':
                case 'name':
                case 'guid':
                case 'action':
                case 'viewSuffix':
                    $name = '_' . $key;
                    $this->$name = trim($value);
                    break;
                case 'format':
                    $this->setFormat($value);
                    break;
                case 'data':
                    $this->loadData($value);
                    break;
                default:
                    break;
            }
        }
        return $this;
    }

    /**
     * 視圖物件
     *
     * @var Zend_View_Abstract
     */
    protected $_view = null;

    /**
     * 設定視圖物件
     *
     * @param Zend_View_Abstract $view
     * @return Wacow_Weblet_Abstract
     */
    public function setView(Zend_View_Abstract $view)
    {
        $this->_view = clone $view;
        return $this;
    }

    /**
     * 取得視圖物件
     *
     * @return Zend_View_Abstract
     */
    public function getView()
    {
        if (null === $this->_view) {
            $this->_view = new Zend_View();
        }
        return $this->_view;
    }

    /**
     * Weblet 資料
     *
     * @var array
     */
    protected $_data = array();

    /**
     * 設定 Weblet 資料
     *
     * @param string $name
     * @param mixed $value
     */
    public function __set($name, $value)
    {
        if (array_key_exists($name, $this->_data)) {
            $this->_data[$name] = $value;
        }
    }

    /**
     * 取得 Weblet 資料
     *
     * @param $name $name
     * @return mixed
     */
    public function __get($name)
    {
        if ('guid' === strtolower($name)) {
            return $this->getGuid();
        }
        if (array_key_exists($name, $this->_data)) {
            return $this->_data[$name];
        }
        return null;
    }

    /**
     * 取得屬性
     *
     * @param string $name
     * @param array $args
     * @return string
     */
    public function __call($name, $args)
    {
        $propertyName = '_' . strtolower($name);
        if (property_exists($this, $propertyName)) {
            return $this->$propertyName;
        }
    }

    /**
     * 載入資料
     *
     * @param array $data
     * @return Wacow_Weblet_Abstract
     */
    public function loadData($data)
    {
        $data = array_intersect_key($data, $this->_data);

        foreach ($data as $key => $value) {
            $this->__set($key, $value);
        }

        return $this;
    }

    /**
     * 初始化
     *
     */
    public function init()
    {
    }

    /**
     * 驗證資料
     *
     * @return bool
     */
    public function validate()
    {
        return true;
    }

    /**
     * 預設動作
     * 
     */
    public function defaultAction()
    {
    }

    /**
     * 執行
     *
     */
    public function execute()
    {
        $actionName = $this->_getActionName();
        if ($this->validate()) {
            $this->$actionName();
            $this->setExecuted();
            return true;
        }
        return false;
    }

    /**
     * 取得要執行的動作
     *
     * @return string
     */
    protected function _getActionName()
    {
        $actionName = $this->_formatActionName($this->_action) . 'Action';
        if (is_callable(array($this, $actionName))) {
            return $actionName;
        }
        return 'defaultAction';
    }

    /**
     * 轉換動作名稱
     *
     * @param mixed $unformatted
     * @return string
     */
    protected function _formatActionName($unformatted)
    {
        $segments = explode('-', $unformatted);
        foreach ($segments as $key => $segment) {
            if ($key) {
                $segments[$key] = ucfirst(strtolower($segment));
            } else {
                $segments[$key] = strtolower($segment);
            }
        }
        return implode('', $segments);
    }

    /**
     * 顯示
     *
     * @return string
     */
    public function render()
    {
        $format = strtolower($this->_format);
        $acceptedFormats = $this->getAcceptedFormats();
        if (array_key_exists($format, $acceptedFormats)) {
            $callback = $acceptedFormats[$format];
            if (is_callable($callback)) {
                return call_user_func($callback);
            } else {
                $methodName = '_renderAs' . ucfirst($format);
                if (method_exists($this, $methodName)) {
                    return $this->$methodName();
                }
            }
        }
        return '';
    }

    /**
     * 輸出 JSON
     *
     * @return string
     */
    protected function _renderAsJson()
    {
        $this->getView()->assign('guid', $this->getGuid());
        return Zend_Json::encode($this->getView()->getVars());
    }

    /**
     * 輸出 HTML
     *
     * @return string
     */
    protected function _renderAsHtml()
    {
        if ('' === trim($this->getName())) {
            return '';
        }
        $script = $this->getName() . '.' . $this->_viewSuffix;
        $this->getView()->assign('weblet', $this);
        return $this->getView()->render($script);
    }

    /**
     * 產生前端用 HTML 表單欄位
     *
     * @param string $name
     * @param string $value
     * @return string
     */
    public function field($name, $value)
    {
        return '<input type="hidden" name="'
             . $this->fieldName($name)
             . '" value="' . $value . '" />';
    }

    /**
     * 產生前端用 HTML 表單欄位群組
     *
     * @param string $action 動作
     * @param string $format 輸出格式
     * @return string
     */
    public function fields($action, $format)
    {
        $fields  = '';
        $fields .= $this->field('_name', $this->getName());
        $fields .= $this->field('_format', $format);
        $fields .= $this->field('_action', $action);
        $fields .= $this->field('_guid', $this->getGuid());
        return $fields;
    }

    /**
     * 取得前端用 HTML 表單欄位名稱
     *
     * @see Wacow_Weblet_Abstract::fieldName()
     * @param string $name
     * @return string
     */
    public function fn($name)
    {
        return $this->fieldName($name);
    }

    /**
     * 取得前端用 HTML 表單欄位名稱
     *
     * @param string $name
     * @return string
     */
    public function fieldName($name)
    {
        return "weblet[{$this->_id}][$name]";
    }

    /**
     * 是否已經執行
     *
     * @var bool
     */
    protected $_isExecuted = false;

    /**
     * 設定已經執行
     *
     * @param bool $value
     */
    public function setExecuted($flag = true)
    {
        $this->_isExecuted = (bool) $flag;
    }

    /**
     * 是否已經執行
     *
     * @return bool
     */
    public function isExecuted()
    {
        return $this->_isExecuted;
    }
}