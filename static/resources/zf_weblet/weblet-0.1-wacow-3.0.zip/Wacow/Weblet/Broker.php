<?php
/**
 * Wacow Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Wacow
 * @package    Wacow_Weblet
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id$
 */

/**
 * Weblet 管理類別
 *
 * @package    Wacow_Weblet
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Wacow_Weblet_Broker
{
    /**
     * 載入器
     *
     * @var Zend_Loader_PluginLoader
     */
    protected static $_pluginLoader = null;

    /**
     * 設定 Plugin Loader
     *
     * @param  Zend_Loader_PluginLoader_Interface $loader
     * @return void
     */
    public function setPluginLoader($loader)
    {
        if ((null !== $loader) && (!$loader instanceof Zend_Loader_PluginLoader_Interface)) {
            require_once 'Zend/Controller/Action/Exception.php';
            throw new Zend_Controller_Action_Exception('Invalid plugin loader provided to HelperBroker');
        }
        self::$_pluginLoader = $loader;
    }

    /**
     * 取得 Plugin Loader
     *
     * @return Zend_Loader_PluginLoader
     */
    public function getPluginLoader()
    {
        if (null === self::$_pluginLoader) {
            require_once 'Zend/Loader/PluginLoader.php';
            self::$_pluginLoader = new Zend_Loader_PluginLoader(array(
                'Wacow_Weblet_' => 'Wacow/Weblet',
            ));
        }
        return self::$_pluginLoader;
    }

    /**
     * 加入前置字串
     *
     * @param string $prefix
     */
    public function addPrefix($prefix, $path = null)
    {
        $prefix = rtrim($prefix, '_');
        if (null === $path) {
            $path = str_replace('_', DIRECTORY_SEPARATOR, $prefix);
        }
        $this->getPluginLoader()->addPrefixPath($prefix, $path);
    }

    /**
     * 預設選項
     *
     * @var array
     */
    protected $_defaultOptions = array();

    /**
     * 設定預設選項
     *
     * @param array $options
     */
    public function setDefaultOptions($options)
    {
        $this->_defaultOptions = (array) $options;
    }

    /**
     * 取得預設選項
     *
     * @return array
     */
    public function getDefaultOptions()
    {
        return $this->_defaultOptions;
    }

    /**
     * 從尚未處理的資訊中載入 Weblet
     *
     * @param array $info
     */
    public function loadWebletFromUnprocessInfo($info)
    {
        $info = (array) $info;
        $index = 0;
        $firstWeblet = null;
        foreach ($info as $id => $params) {
            $name = $this->_getWebletName($params);
            if (empty($name)) { continue; }
            $weblet = $this->createWeblet($name);
            /* @var $weblet Wacow_Weblet_Abstract */
            $options = array(
                'name'   => $name,
                'action' => $this->_getAction($params),
                'format' => $this->_getFormat($params),
                'guid'   => $this->_getGuid($params),
                'data'   => $this->_getData($params),
            );
            $weblet->setOptions($options);
            $this->addWeblet($id, $weblet);
            if (0 === $index) { $firstWeblet = $weblet; }
            $index ++;
        }
        return $firstWeblet;
    }

    /**
     * 取得 Weblet
     *
     * @param string $name
     * @return Wacow_Weblet_Abstract
     */
    public function createWeblet($name, $id = null)
    {
        if (null === $id) {
            $id = $name;
        }

        $newName = $this->_formatWebletName($name);
        try {
            $className = $this->getPluginLoader()->load($newName);
        } catch (Zend_Loader_PluginLoader_Exception $e) {
            throw new Zend_Loader_PluginLoader_Exception('Weblet by name ' . $newName . ' not found');
        }

        $weblet = new $className(); /* @var $weblet Wacow_Weblet_Abstract */
        $weblet->setOptions($this->getDefaultOptions());
        $weblet->setId($id);
        $weblet->init();

        $this->addWeblet($id, $weblet);
        return $weblet;
    }

    /**
     * Weblets
     *
     * @var array
     */
    protected $_weblets = array();

    /**
     * 加入 Weblet
     *
     * @param string $id
     * @param Wacow_Weblet_Abstract $weblet
     */
    public function addWeblet($id, Wacow_Weblet_Abstract $weblet)
    {
        $this->_weblets[$id] = $weblet;
    }

    /**
     * 取得已經存在的 Weblet
     *
     * @param string $name
     * @return Wacow_Weblet_Abstract
     */
    public function getWeblet($id)
    {
        return isset($this->_weblets[$id])
             ? $this->_weblets[$id]
             : null;
    }

    /**
     * 轉換 Weblet 名稱
     *
     * @param mixed $unformatted
     * @return string
     */
    protected function _formatWebletName($unformatted)
    {
        $segments = (array) $unformatted;
        foreach ($segments as $key => $segment) {
            $segment = str_replace('-', ' ', strtolower($segment));
            $segment = preg_replace('/[^a-z0-9 ]/', '', $segment);
            $segments[$key] = str_replace(' ', '', ucwords($segment));
        }

        return implode('', $segments);
    }

    /**
     * 取得 Weblet 名稱
     *
     * @param array $params
     * @return string
     */
    protected function _getWebletName($params)
    {
        return $this->_processParams($params, '_name', '');
    }

    /**
     * 取得 Weblet 要用的 action
     *
     * @param array $params
     * @return string
     */
    protected function _getAction($params)
    {
        return $this->_processParams($params, '_action', 'default');
    }

    /**
     * 取得 Weblet 要用的 format
     *
     * @param array $params
     * @return string
     */
    protected function _getFormat($params)
    {
        return $this->_processParams($params, '_format', 'html');
    }

    /**
     * 取得 Weblet 要用的 GUID
     *
     * @param array $params
     * @return string
     */
    protected function _getGuid($params)
    {
        return $this->_processParams($params, '_guid', '');
    }

    /**
     * 處理參數
     *
     * @param array $params
     * @param string $part
     * @param string $default
     */
    private function _processParams($params, $part, $default)
    {
        $result = $default;
        if (isset($params[$part])) {
            $result = trim($params[$part]);
        }
        return $result;
    }

    /**
     * 取得 Weblet 要用的 data
     *
     * @param array $params
     * @return array
     */
    protected function _getData($params)
    {
        $data = $params;
        unset($data['_weblet']);
        unset($data['_action']);
        unset($data['_format']);
        return $data;
    }

    /**
     * 私有建構子
     *
     */
    private function __construct()
    {}

    /**
     * 不可複製
     *
     */
    private function __clone()
    {}

    /**
     *
     * @var Wacow_Weblet_Broker
     */
    private static $_instance = null;

    /**
     *
     * @return Wacow_Weblet_Broker
     */
    public static function getInstance()
    {
        if (null === self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
}