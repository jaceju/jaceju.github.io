<?php
/**
 * Wacow Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Wacow
 * @package    Wacow_Application
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id$
 */

/**
 * @see Zend_Application_Resource_ResourceAbstract
 */
require_once 'Zend/Application/Resource/ResourceAbstract.php';

/**
 * 處理 Auth
 *
 * @package    Wacow_Application
 * @subpackage Wacow_Application_Resource
 * @copyright  Copyright (c) 2010-2018 Wabow Information Inc. (http://www.wabow.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Wacow_Application_Resource_Weblet extends Zend_Application_Resource_ResourceAbstract
{
    /**
     * Weblet 路徑
     *
     * @var array
     */
    protected $_webletPaths = array();

    /**
     * 初始化
     *
     */
    public function init()
    {
        $this->_initWebletPaths();
        $this->_setLoader();
        $this->_setBroker();
    }

    /**
     * 初始化路徑
     *
     */
    protected function _initWebletPaths()
    {
        $options = $this->getOptions();
        if (array_key_exists('webletPath', $options)) {
            $this->_webletPaths = (array) $options['webletPath'];
        }
    }

    /**
     * 設定載入器
     *
     */
    protected function _setLoader()
    {
        $resourceLoader = new Zend_Loader_Autoloader_Resource(array(
            'basePath'      => APPLICATION_PATH,
            'namespace'     => 'Application',
            'resourceTypes' => array(
                'weblet' => array(
                    'path' => 'weblets/',
                    'namespace' => 'Weblet',
                ),
            ),
        ));
    }

    /**
     * 設定 Weblet 代理
     *
     */
    protected function _setBroker()
    {
        $options = $this->getOptions();
        $broker = Wacow_Weblet_Broker::getInstance();
        foreach ($this->_getWebletPaths() as $prefix => $path) {
            $broker->addPrefix($prefix, $path);
        }
        $broker->setDefaultOptions(array(
            'view' => $this->_getView(),
            'viewSuffix' => $this->_getViewSuffix(),
        ));
    }

    /**
     * 取得 Weblet 路徑
     *
     * @return array
     */
    protected function _getWebletPaths()
    {
        return $this->_webletPaths;
    }

    /**
     * 取得目前使用的 View
     *
     */
    protected function _getView()
    {
        $view = Zend_Controller_Action_HelperBroker::getStaticHelper('ViewRenderer')->view;
        /* @var $view Zend_View_Abstract */
        foreach ($this->_getWebletPaths() as $prefix => $path) {
            $view->addBasePath($path);
        }
        return $view;
    }

    /**
     * 取得 View
     *
     * @return string
     */
    protected function _getViewSuffix()
    {
        return Zend_Controller_Action_HelperBroker::getStaticHelper('ViewRenderer')
            ->getViewSuffix();
    }
}