<?php
require "main.php";
$forum = array(
    array("category_id" => 1, "category_name" => "公告區",
        "topic" => array(
            array("topic_id" => 1, "topic_name" => "站務公告")
        )
    ),
    array("category_id" => 2, "category_name" => "文學專區",
        "topic" => array(
            array("topic_id" => 2, "topic_name" => "好書介紹"),
            array("topic_id" => 3, "topic_name" => "奇文共賞")
        )
    ),
    array("category_id" => 3, "category_name" => "電腦專區",
        "topic" => array(
            array("topic_id" => 4, "topic_name" => "硬體週邊"),
            array("topic_id" => 5, "topic_name" => "軟體討論")
        )
    )
);
$tpl->assign("forum", $forum);
$tpl->display("test3.htm");
?>