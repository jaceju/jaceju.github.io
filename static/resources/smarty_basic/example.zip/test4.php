<?php
require "main.php";
$my_array = array(
    array("value" => "0"),
    array("value" => "1"),
    array("value" => "2"),
    array("value" => "3"),
    array("value" => "4"),
    array("value" => "5"),
    array("value" => "6"),
    array("value" => "7"),
    array("value" => "8"),
    array("value" => "9"));
$tpl->assign("my_array", $my_array);
$tpl->display('test4.htm');
?>