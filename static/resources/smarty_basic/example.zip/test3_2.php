<?php
require "main.php";

// 建立資料庫連結
$mysqli = new mysqli("localhost", "username", "password", "testdb");

// 先建立第一層陣列及 SQL 指令
$category = array();
$sql1 = "SELECT category_id, category_name FROM categories";

// 抓取第一層迴圈的資料
if ($result1 = $mysqli->query($sql1)) {

    while ($item_category = $result1->fetch_assoc())
    {
        // 建立第二層陣列及 SQL 指令
        $topic = array();
        $sql2 = sprintf(
            "SELECT topic_id, topic_name FROM topics WHERE category_id = '%s'",
            $item_category['category_id']
        );

        // 抓取第二層迴圈的資料
        if ($result2 = $mysqli->query($sql2)) {
            while ($item_topic = $result2->fetch_assoc())
            {
                // 把抓取的資料推入第二層陣列中
                array_push($topic, $item_topic);
            }
            $result2->close();
        }

        // 把第二層陣列指定為第一層陣列所抓取的資料中的一個成員
        $item_category['topic'] = $topic;

        // 把第一層資料推入第一層陣列中
        array_push($category, $item_category);

        $result1->close();
    }
}
$mysqli->close();

$tpl->assign("forum", $category);
$tpl->display("test3.htm");
?>