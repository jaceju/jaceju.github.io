<?php
include ('admin_main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 取得文章列表
//===============================================
$article_list = &$db->getAll(
  "SELECT * FROM article ORDER BY article_id DESC"
);

if (DB::isError($article_list))
{
  header("Content-Type: text/plain; charset=big5");
  die ($article_list->getMessage());
}

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('article_list', $article_list);

//===============================================
// 顯示頁面
//===============================================
$smarty->display('admin_article_list.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>