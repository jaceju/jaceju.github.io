<?php
include ('main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 取得文章列表
//===============================================
// 指定某一天
if (isset($_GET["date"]))
{
  $selected_day =
    (-1 != $temp_date = strtotime($_GET["date"]))
    ? date("Y-m-d", $temp_date)
    : date("Y-m-d");

  $sql = "SELECT * FROM article " .
    "WHERE DATE_FORMAT(pubDate, '%Y-%m-%d') = ?" .
    "ORDER BY article_id DESC";

  $article_list = 
    &$db->getAll($sql, array ($selected_day)); 

  if (!$article_list)
    header('Location: index.php');
}
// 指定某分類
elseif (isset($_GET["cid"]))
{
  $sql = "SELECT * FROM article " .
    "WHERE category_id = ?" .
    "ORDER BY article_id DESC";

  $article_list = 
    &$db->getAll($sql, array ($_GET["cid"]));  
}
// 都沒有指定的話就顯示全部
else
{
  $sql = "SELECT * FROM article ORDER BY article_id DESC";
  $article_list = &$db->getAll($sql);  
}

if (DB::isError($article_list))
{
  header("Content-Type: text/plain; charset=big5");
  die ($article_list->getMessage());
}

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('article_list', $article_list);

//===============================================
// 載入邊欄程式
//===============================================
include ('sidebar.php');

//===============================================
// 顯示頁面
//===============================================
$smarty->display('article_list.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>