<?php
require_once 'DB/mysql.php';

class MySQLWrapper extends DB_mysql
{
    var $connection = NULL;

    var $_version = 4;

    var $_client_character_set = 'latin1';

    var $_server_character_set = 'latin1';

    var $_client_encoding = 'latin1';

    var $_apply_character_sets = array ('big5', 'utf8');
    
    var $_is_escape = FALSE;

    function MySQLWrapper(&$db, $charset = 'latin1')
    {
        $this->connection = &$db->connection;
        $this->_version = (float) mysql_get_server_info($this->connection);
        $this->_client_character_set = strtolower($charset);
        $this->_client_encoding = strtolower(mysql_client_encoding($this->connection));

        $variables_name = 'character_set';

        // �� MySQL �����b 4.1 �H�W
        if ($this->_version > 4)
        {
            $variables_name = 'character_set_server';
            if ('latin1' == $this->_client_character_set)
            {
                mysql_query("SET NAMES binary", $this->connection);
            }
            else
            {
                mysql_query("SET NAMES " . $this->_client_character_set, $this->connection);
            }
            $this->_apply_character_sets = array ('big5');
        }
        $result = mysql_query("SHOW VARIABLES LIKE '$variables_name'", $this->connection);
        $row = mysql_fetch_assoc($result);
        $this->_server_character_set = strtolower($row['Value']);

        $this->_is_escape = in_array($this->_client_character_set, $this->_apply_character_sets);
    }
    
    function escapeSimple($str)
    {
        if ($this->_client_encoding != 'big5')
        {
            $output = parent::escapeSimple($str);
        }
        else
        {
            $output = addslashes($str);
        }
        // echo "no special escape: ", $output, "<br />\n";
        if ($this->_is_escape)
        {
            $search = array ('/([\xa1-\xf9][\x5c])[\x5c]/');
            $replace = array ('\1');
            $output = preg_replace($search, $replace, $output);
        // echo "special escape: ", $output, "<br />\n";
        }
        
        return $output;
    }

    function getServerInfo()
    {
        return mysql_get_server_info($this->connection);
    }

    function getClientInfo()
    {
        return mysql_get_client_info();
    }

    function getClientEncoding()
    {
        return $this->_client_encoding;
    }

    function getVersion()
    {
        return $this->_version;
    }

    function getServerCharSet()
    {
        return $this->_server_character_set;
    }

    function getClientCharSet()
    {
        return $this->_client_character_set;
    }

}
?>
