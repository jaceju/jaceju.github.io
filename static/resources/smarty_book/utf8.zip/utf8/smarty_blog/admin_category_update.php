<?php
include ('admin_main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 如果為 POSTBACK ，則修改分類內容
//===============================================
if (isset($_POST['postback']) && 'true' == $_POST['postback'])
{
  $sql_handle = &$db->prepare(
    "UPDATE category SET " .
    "title = ?, " .
    "description = ? " .
    "WHERE category_id = ?"
  );

  $result = &$db->execute($sql_handle,
    array (
      $_POST['title'],
      $_POST['description'],
      $_POST['category_id']
    )
  );

  if (DB::isError($result))
  {
    header("Content-Type: text/plain; charset=big5");
    die ($result->getMessage());
  }

  $db->disconnect();

  header('Location: admin_category_list.php');
  exit;
}

//===============================================
// 取得指定的分類內容
//===============================================
$category_detail = &$db->getRow(
  "SELECT * FROM category WHERE category_id = ?",
  array ($_GET['cid'])
);

if (DB::isError($category_detail))
{
  die ($category_detail->getMessage());
}

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('page_title', '修改分類');

$smarty->assign('category_detail', $category_detail);

$smarty->display('admin_category_edit.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>
