<?php
function smarty_modifier_nl2p($value, $style = '') {
    $style = ('' != $style) ? " style=\"$style\"" : '';
    $new_str = preg_replace('/<br \/>\s*<br \/>/',
        "</p>\n<p$style>",
        nl2br($value));
    return "<p$style>" . $new_str . "</p>" . "\n";
}
?>