<?php
include ('admin_main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 取得分類列表
//===============================================
$category_list = &$db->getAll(
  "SELECT * FROM category ORDER BY category_id"
);

if (DB::isError($category_list))
{
  header("Content-Type: text/plain; charset=big5");
  die ($category_list->getMessage());
}

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('category_list', $category_list);

//===============================================
// 顯示頁面
//===============================================
$smarty->display('admin_category_list.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>