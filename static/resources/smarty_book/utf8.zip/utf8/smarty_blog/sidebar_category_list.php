<?php
//===============================================
// 取得前端頁面的分類列表
//===============================================
$category_list = &$db->getAll(
  "SELECT * FROM category ORDER BY category_id"
);

if (DB::isError($category_list))
{
  header("Content-Type: text/plain; charset=big5");
  die ($category_list->getMessage());
}

//===============================================
// 樣版處理
//===============================================
$smarty->assign('category_list', $category_list);
?>