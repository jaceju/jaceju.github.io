<?php
include ('main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 取出文章的 RSS 資訊
//===============================================
$rss_items = &$db->getAll(
  "SELECT a.*, c.title AS category_title " .
  "FROM article AS a, category AS c " .
  "WHERE a.category_id = c.category_id " .
  "ORDER BY a.article_id DESC"
);

if (DB::isError($rss_items))
{
  header("Content-Type: text/plain; charset=big5");
  die ($rss_items->getMessage());
}

//===============================================
// 將時間代換成符合 RSS 格式的字串
//===============================================
foreach ($rss_items as $key => $item)
{
  $item['pubDate'] = 
    date("r", strtotime($item['pubDate']));
  $rss_items[$key] = $item;
}

//===============================================
// 建立網站完整網址
//===============================================
$site_link  = 'http://';
$site_link .= $_SERVER["HTTP_HOST"];
$site_link .= RELATIVE_PATH;

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('site_link', $site_link);

$smarty->assign('create_date', date("r"));

$smarty->assign('rss_items', $rss_items);

//===============================================
// 取得代換後的 RSS 內容
//===============================================
$rss = $smarty->fetch('rss.tpl.xml');

//===============================================
// 輸出正確的 Content-Type
//===============================================
header("Content-Type: text/xml; charset=utf-8");
echo iconv('IS_MYSQL_BIG5', 'UTF-8', $rss);

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>