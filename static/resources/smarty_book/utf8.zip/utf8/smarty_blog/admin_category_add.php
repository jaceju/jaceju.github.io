<?php
include ('admin_main.php');

//===============================================
// 如果為 POSTBACK ，則新增分類內容
//===============================================
if (isset($_POST['postback']) && 'true' == $_POST['postback'])
{
  $db = &getDB(DB_DSN);
  
  $sql_handle = &$db->prepare(
    "INSERT INTO category (title, description) " .
    "VALUES (?, ?)"
  );

  $result = &$db->execute($sql_handle,
    array (
      $_POST['title'],
      $_POST['description']
    )
  );

  if (DB::isError($result))
  {
    header("Content-Type: text/plain; charset=big5");
    die ($result->getMessage());
  }

  $db->disconnect();

  header('Location: admin_category_list.php');

  exit;
}

//===============================================
// 指定一個空白的分類內容
//===============================================
$category_detail = array (
  'category_id' => 0,
  'title'     => '',
  'description' => ''
);

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('category_detail', $category_detail);

$smarty->assign('page_title', '新增分類');



//===============================================
// 顯示頁面
//===============================================
$smarty->display('admin_category_edit.tpl.htm');
?>
