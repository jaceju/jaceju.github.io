<?php
//===============================================
// 載入設定檔
//===============================================
require_once ('config.php');

//===============================================
// 設定引用路徑
//===============================================
$includePath = array(APP_REAL_PATH . '/class', get_include_path());
set_include_path(join(PATH_SEPARATOR, $includePath));

//===============================================
// 引用必要類別
//===============================================
require_once ('DB.php');
require_once ('MySQLWrapper.php');
require_once ('Template.php');

//===============================================
// 清除登入資訊
//===============================================
session_start();
unset($_SESSION['LOGIN']);

//===============================================
// 去除 Magic Quotes 的影響
//===============================================
if (get_magic_quotes_gpc())
{
  $_GET = array_map('stripslashes', $_GET);
  $_POST = array_map('stripslashes', $_POST);
  $_COOKIE = array_map('stripslashes', $_COOKIE);
  $_REQUEST = array_map('stripslashes', $_REQUEST);
}

//===============================================
// 取得資料庫連結
//===============================================
function getDB($dsn)
{
  // 建立資料庫連結
  $db = &DB::connect($dsn);

  if (DB::isError($db))
  {
    header("Content-Type: text/plain; charset=utf8");
    die ($db->getMessage());
  }

  $db = new MySQLWrapper($db, DB_CHAR_SET);

  return $db;
}