DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `article_id` int(10) unsigned NOT NULL auto_increment,
  `category_id` int(10) unsigned NOT NULL default '0',
  `title` varchar(200) NOT NULL default '',
  `author` varchar(40) NOT NULL default '',
  `description` text NOT NULL,
  `content` text,
  `pubDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `lastBuildDate` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`article_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(200) NOT NULL default '',
  `description` text,
  PRIMARY KEY  (`category_id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `comment_id` int(10) unsigned NOT NULL auto_increment,
  `article_id` int(10) NOT NULL default '0',
  `visitorname` varchar(40) NOT NULL default '',
  `comment` text NOT NULL,
  `createDate` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`comment_id`)
) ENGINE=MyISAM;