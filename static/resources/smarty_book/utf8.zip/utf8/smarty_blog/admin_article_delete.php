<?php
include ('admin_main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

//===============================================
// 刪除文章
//===============================================
$sql_handle = &$db->prepare(
  "DELETE FROM article " .
  "WHERE article_id = ?"
);

$result = &$db->execute($sql_handle,
  array ($_GET['aid'])
);

if (DB::isError($result))
{
    die ($result->getMessage());
}

//===============================================
// 結束程式，釋放資料庫連結，並導回列表頁
//===============================================
$db->disconnect();

header('Location: admin_article_list.php');
?>