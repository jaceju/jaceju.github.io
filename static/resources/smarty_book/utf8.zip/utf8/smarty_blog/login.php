<?php
include ('main.php');

//===============================================
// 如果帳號及密碼正確的話，導向管理頁面
//===============================================
if (BLOG_AUTHOR == $_POST['author'] &&
  BLOG_PASSWD == $_POST['passwd'])
{
  $_SESSION['LOGIN'] = TRUE;
  header("Location: admin_article_list.php");
  exit;
}

//===============================================
// 預設導回首頁
//===============================================
header("Location: index.php");
exit;
?>