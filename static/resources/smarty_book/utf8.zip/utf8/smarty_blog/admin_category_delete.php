<?php
include ('admin_main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

//===============================================
// 刪除分類
//===============================================
$sql_handle = &$db->prepare(
  "DELETE FROM category " .
  "WHERE category_id = ?"
);

$result = &$db->execute($sql_handle,
  array ($_GET['cid'])
);

if (DB::isError($result))
{
    die ($result->getMessage());
}

//===============================================
// 結束程式，釋放資料庫連結，並導回列表頁
//===============================================
$db->disconnect();

header('Location: admin_category_list.php');
?>