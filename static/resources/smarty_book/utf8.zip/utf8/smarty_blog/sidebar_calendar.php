<?php
//===============================================
// 建立月曆
//===============================================
// 取得該月有哪幾天有文章
$article_days = &$db->getCol(
  "SELECT DISTINCT DATE_FORMAT(pubDate, '%e') AS DAYS " . 
  "FROM `article` " .
  "WHERE DATE_FORMAT(pubDate, '%c') = " . date("m")
);

// 如果無法取得資料，則顯示錯誤訊息
if (DB::isError($article_days))
{
  header("Content-Type: text/plain; charset=big5");
  die ($article_days->getMessage());
}

// 取得今天的年、月
$now = getdate();

$calendar_year = $now['year'];

$calendar_month = $now['mon'];

// 將這個月轉換為 timestamp 格式
$this_month = mktime(
  0, 0, 0, // hour, minute, second
  $calendar_month, 1, $calendar_year // month, day, year
);

// 取得該月的最後一天
$last_day = date("t", $this_month);

// 取得該月第一天是星期幾
$start_weekday = date("w", $this_month);

// 是否為該月第一天
$is_first_day = TRUE;

// 是否為該月最後一天
$is_last_day = FALSE;

// 是否為該月最後一週
$is_last_week = FALSE;

// 存放月曆的每一週
$calendar_weeks = array ();

// 從第一週開始，最多六週
// 因為四週共 28 天，加上該月第一天
// 和最後一天可能分別獨自在一週
// 因此四加二等於六
for ($w = 1; $w <= 6; $w ++)
{
  // 存放每個星期的日
  $calendar_days = array ();

  // 從星期天開始，到星期六 (一週)
  for ($d = 0; $d <= 6; $d ++)
  {
    // 存放每一日
    $day_link = array ();

    // 找到該月第一天是星期幾
    if ($is_first_day)
    {
      if ($start_weekday != $d)
      {
        $day = '';
        $is_first_day = TRUE;
      }
      else
      {
        $day = 1;
        $is_first_day = FALSE;
      }
    }

    // 開始存放要顯示的數字
    $day_link['day'] = $day;

    // 如果該天有文章，就設定文章連結
    $day_link['link'] = in_array($day, $article_days);

    // 將顯示數字和連結放到陣列內
    $calendar_days[] = $day_link;

    if (!$is_last_day)
    {
      // 如果已經是最後一天，就不再顯示數字
      if ($last_day == $day)
      {
        $is_last_day = TRUE;
        $day = '';
      }
      // 還不是最後一天就繼續
      else
      {
        $day ++;
      }
    }
    
    // 如果是超過該月最後一天，而且是星期六的話
    // 就算是該月的最後一週
    $is_last_week = (6 == $d && $is_last_day);
  }
  $calendar_weeks[] = $calendar_days;

  // 如果是該月最後一週就離開迴圈
  if ($is_last_week) break;
}

//===============================================
// 樣版處理
//===============================================
$smarty->assign('calendar_year', $calendar_year);

$smarty->assign('calendar_month', $calendar_month);

$smarty->assign('calendar_weeks', $calendar_weeks);
?>
