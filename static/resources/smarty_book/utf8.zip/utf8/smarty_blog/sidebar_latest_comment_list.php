<?php
//===============================================
// 取得最新的 10 筆評論
//===============================================
$result = &$db->limitQuery(
  "SELECT c.visitorname, a.title, a.article_id " .
  "FROM article AS a, comment AS c " .
  "WHERE c.article_id = a.article_id " .
  "ORDER BY c.comment_id DESC", 0, 10
);

if (DB::isError($result))
{
  header("Content-Type: text/plain; charset=big5");
  die ($result->getMessage());
}

$latest_comment_list = array ();
while ($row = $result->fetchRow(DB_FETCHMODE_ASSOC))
{
  $latest_comment_list[] = $row;
}

//===============================================
// 樣版處理
//===============================================
$smarty->assign(
  'latest_comment_list',
  $latest_comment_list
);
?>