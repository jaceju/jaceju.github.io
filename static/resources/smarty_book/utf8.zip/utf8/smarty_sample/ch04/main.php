<?php
require_once ('../class/Smarty/Smarty.class.php');
require_once ('../config.php');

$smarty = new Smarty();
$smarty->template_dir = APP_REAL_PATH . "/templates/";
$smarty->compile_dir = APP_REAL_PATH . "/templates_c/";
?>
