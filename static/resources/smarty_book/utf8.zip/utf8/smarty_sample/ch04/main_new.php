<?php
require_once ('../class/Template.php');
require_once ('../config.php');
?>
