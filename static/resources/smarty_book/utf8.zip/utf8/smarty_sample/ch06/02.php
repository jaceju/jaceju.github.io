<?php
include ('main.php');

$smarty = new Template();

$nums = array (
'num0' => 0,
'num1' => 1,
'num2' => 2,
'num3' => 3,
'num4' => 4,
'num5' => 5,
'num6' => 6,
'num7' => 7,
'num8' => 8,
);

$smarty->assign($nums);

$smarty->display('ch06/02.tpl.htm');
?>
