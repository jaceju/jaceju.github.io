<?php
include ('main.php');

$smarty = new Template();

$condition = array (
'condition1' => TRUE,
'condition2' => FALSE,
'condition3' => TRUE,
'condition4' => FALSE,
);

$smarty->assign($condition);
$smarty->assign('num', 5);

$smarty->display('ch06/01.tpl.htm');
?>
