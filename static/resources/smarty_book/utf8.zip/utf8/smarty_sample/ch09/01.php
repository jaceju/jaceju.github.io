<?php
include ('main.php');

$smarty = new Template();

$smarty->assign('num', 1000);
$smarty->assign('ary', array ('A', 'B', 'C'));

$smarty->debugging = TRUE;

$smarty->display('ch09/01.tpl.htm');
?>
