<?php
include ('main.php');

$smarty = new Template();

$chapters = array (
    array (
        'name' => '樣版及樣版引擎',
        'sections' => array (
            '程式開發與視覺介面的衝突',
            '樣版的概念',
            '什麼是樣版引擎',
            '取捨之間',
            '總結',
        ),
    ),
    array (
        'name' => '樣版引擎的佼佼者：Smarty',
        'sections' => array (
            'Smarty 介紹',
            '安裝 Smarty',
            '總結',
        ),
    ),
    array (
        'name' => 'Smarty 樣版語法',
        'sections' => array (
            '第一次與 Smarty 接觸',
            '變數',
            '條件式判斷',
        ),
    ),
);

$smarty->assign('chapters', $chapters);

$smarty->display('ch07/05_other.tpl.htm');
?>
