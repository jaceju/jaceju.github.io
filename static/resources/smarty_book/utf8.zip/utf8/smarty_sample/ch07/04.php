<?php
include ('main.php');

$smarty = new Template();

$smarty->display('ch07/04.tpl.htm');
?>
