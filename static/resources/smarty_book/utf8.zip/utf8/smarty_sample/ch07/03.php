<?php
include ('main.php');

$smarty = new Template();

$fruits = array (
    '鳳梨',
    '香蕉',
    '芭樂',
    '西瓜',
    '芒果',
    '釋迦'
);

$smarty->assign('fruits', $fruits);
$smarty->assign('class', $class);

$smarty->display('ch07/03.tpl.htm');
?>
