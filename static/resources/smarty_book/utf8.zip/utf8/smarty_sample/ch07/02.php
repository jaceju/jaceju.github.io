<?php
include ('main.php');

$smarty = new Template();

$fruits = array (
    'A' => '鳳梨',
    'B' => '香蕉',
    'C' => '芭樂',
    'D' => '西瓜',
    'E' => '芒果',
    'F' => '釋迦'
);

$smarty->assign('fruits', $fruits);

$smarty->display('ch07/02.tpl.htm');
?>
