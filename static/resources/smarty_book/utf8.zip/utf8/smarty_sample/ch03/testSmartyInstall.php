<?php
//===============================================
// 載入設定檔
//===============================================
require_once ('../config.php');

//===============================================
// PHP5 需要設定時區
//===============================================
if (function_exists('date_default_timezone_set')) {
    date_default_timezone_set('Asia/Taipei');
}

//===============================================
// 載入 Smarty 物件類別
//===============================================
@include ('../class/Smarty/Smarty.class.php');

//===============================================
// 錯誤處理函式
//===============================================
function smarty_error_handler($errno, $errstr, $errfile, $errline)
{
	if (preg_match('@fopen\((.+)/temp.txt\).+Permission denied$@', $errstr, $matches))
	{
			$compiled_dir = $matches[1];
			$errstr = <<<MSG
<p>無法寫入編譯樣版，請檢查</p>
<p><strong> "$compiled_dir" </strong></p>
<p>是否有寫入權限</p>
MSG;
	}
	$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>測試 Smarty 安裝</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<table border="1">
<tr><td bgcolor="#FFCCCC"><strong>Smarty 安裝錯誤！</strong></td></tr>
<tr><td>$errstr</td></tr>
</table>
</body>
</html>
HTML;
	die ($html);
}

//===============================================
// 設定錯誤處理函式
//===============================================
set_error_handler('smarty_error_handler');

//===============================================
// 如果不存在 Smarty 物件類別，就發出錯誤
//===============================================
if (!class_exists('Smarty'))
{
	$include_path = ini_get('include_path');

	$err_msg = <<<MSG
<p>無法引入 Smarty 物件類別，請檢查引入路徑是否正確。</p>
<p>PHP.INI 所設定的引入路徑 (include_path) 為：</p>
<p><strong>"$include_path"</strong></p>
MSG;

	trigger_error($err_msg, E_ERROR);
}

//===============================================
// 確認存放已編譯樣版路徑是否可寫入
//===============================================
$compiled_dir = APP_REAL_PATH . "/templates_c/";
$test_file = $compiled_dir . "temp.txt";
$fp = @fopen($test_file, 'w');

if ($fp) fclose($fp);

if (!is_writable($test_file))
{
	$err_msg = <<<MSG
<p>無法寫入編譯樣版，請檢查</p>
<p><strong>"$compiled_dir"</strong></p>
<p>是否有寫入權限</p>
MSG;

	trigger_error($err_msg, E_ERROR);
}

//===============================================
// 復原錯誤處理器
//===============================================
restore_error_handler();

//===============================================
// 建立 Smarty 物件
//===============================================
$smarty = new Smarty();

//===============================================
// 設定 Smarty 屬性
//===============================================
$smarty->template_dir = APP_REAL_PATH . "/templates/";
$smarty->compile_dir = APP_REAL_PATH . "/templates_c/";

//===============================================
// 指定變數內容
//===============================================
$smarty->assign('message', ' Smarty 已成功安裝！');

//===============================================
// 顯示樣版
//===============================================
$smarty->display('ch03/testSmartyInstall.tpl.htm');
