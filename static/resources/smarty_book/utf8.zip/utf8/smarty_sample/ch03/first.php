<?php
include ('../class/Smarty/Smarty.class.php');

$smarty = new Smarty();
$smarty->template_dir = "d:/web/projects/smarty_book_utf8/smarty_sample/templates/";
$smarty->compile_dir = "d:/web/projects/smarty_book_utf8/smarty_sample/templates_c/";

$num1 = 1000;
$num2 = 2000;
$num3 = $num1 + $num2;

$smarty->assign('num3', $num3);

$smarty->display('ch03/first.tpl.htm');
