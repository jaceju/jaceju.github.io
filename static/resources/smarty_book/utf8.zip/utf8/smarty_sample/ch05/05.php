<?php
include ('main.php');

$smarty = new Template();

$smarty->config_dir = APP_REAL_PATH . "/config/";

$smarty->display('ch05/05.tpl.htm');
?>
