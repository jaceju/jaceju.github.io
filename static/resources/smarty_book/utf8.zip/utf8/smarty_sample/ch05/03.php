<?php
include ('main.php');

$smarty = new Template();

class Sample
{
    var $num1 = 1000;
    var $num2 = 2000;

    function getNum3()
    {
    return $this->num1 + $this->num2;
    }
}

$object = new Sample();

$smarty->assign('object', $object);

$smarty->display('ch05/03.tpl.htm');
?>
