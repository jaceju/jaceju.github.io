<?php
include ('main.php');

$smarty = new Template();

$num1 = 1000;
$num2 = 2000;
$num3 = $num1 + $num2;

$smarty->assign(array ('num1' => $num1, 'num2' => $num2));
$smarty->assign('num3', $num3);

$smarty->display('ch05/06.tpl.htm');
?>
