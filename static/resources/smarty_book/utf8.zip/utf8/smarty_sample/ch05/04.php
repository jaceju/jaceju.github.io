<?php
include ('main.php');

$smarty = new Template();

$smarty->config_dir = APP_REAL_PATH . "/config/";

$smarty->config_load('ch05/04.conf');

$smarty->display('ch05/04.tpl.htm');
?>
