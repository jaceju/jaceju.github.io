<?php
include ('main.php');

$smarty = new Template();

$smarty->caching = TRUE;

$smarty->assign('create_time', date("Y-m-d H:i:s"));

$smarty->cache_lifetime = 5;

$smarty->display('ch10/03.tpl.htm');
?>
