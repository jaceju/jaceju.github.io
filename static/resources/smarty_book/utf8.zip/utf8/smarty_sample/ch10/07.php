<?php
include ('main.php');

$smarty = new Template();

$smarty->caching = TRUE;

if (!$smarty->is_cached('ch10/07.tpl.htm'))
{
    $smarty->assign('start_time', date("Y-m-d H:i:s"));
    
    //做一些複雜且耗時的工作
    do_complex_work();

    $smarty->assign('end_time', date("Y-m-d H:i:s"));
}

$smarty->display('ch10/07.tpl.htm');

function do_complex_work()
{
    for ($i = 0; $i < 200000; $i ++) $temp = rand();
}
?>
