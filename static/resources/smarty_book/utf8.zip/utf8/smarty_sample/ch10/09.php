<?php
include ('main.php');

$smarty = new Template();

$smarty->clear_all_cache();

echo '已清除全部快取！';
?>
