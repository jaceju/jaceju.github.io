<?php
include ('main.php');

$smarty = new Template();

$num = $_GET["num"];
$num_ary = array ("1", "2", "3", "4", "5");

if (in_array($num, $num_ary))
{
    $smarty->clear_cache('ch10/08.tpl.htm', $num);

    echo "已清除範例 8 編號 $num 的快取<br />";
}
else
{
    echo '錯誤的編號';
}
?>
