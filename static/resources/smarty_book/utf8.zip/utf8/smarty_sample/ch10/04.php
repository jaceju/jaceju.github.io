<?php
include ('main.php');

$smarty = new Template();

$smarty->caching = 2;

$smarty->assign('create_time', date("Y-m-d H:i:s"));

$smarty->cache_lifetime = 10;

$sub_page = $smarty->fetch('ch10/04_sub.tpl.htm');

$smarty->cache_lifetime = 5;

$smarty->assign('sub_page', $sub_page);

$smarty->display('ch10/04.tpl.htm');
?>
