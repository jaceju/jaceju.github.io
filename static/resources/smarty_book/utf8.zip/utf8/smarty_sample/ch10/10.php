<?php
include ('main.php');

$smarty = new Template();

$smarty->clear_cache('ch10/01.tpl.htm');

echo '已清除範例 1 的快取<br />';

$smarty->clear_cache('ch10/07.tpl.htm');

echo '已清除範例 7 的快取<br />';
?>
