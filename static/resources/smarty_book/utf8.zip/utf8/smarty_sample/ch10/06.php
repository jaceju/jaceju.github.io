<?php
include ('main.php');

$smarty = new Template();

$smarty->caching = TRUE;

$smarty->assign('start_time', date("Y-m-d H:i:s"));

for ($i = 0; $i < 200000; $i ++) $temp = rand();
    
$smarty->assign('end_time', date("Y-m-d H:i:s"));

$smarty->display('ch10/06.tpl.htm');
?>
