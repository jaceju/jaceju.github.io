<?php
include ('main.php');

$smarty = new Template();

$smarty->caching = TRUE;

$smarty->assign('create_time', date("Y-m-d H:i:s"));

$num = $_GET["num"];
$num_ary = array ("1", "2", "3", "4", "5");

if (in_array($num, $num_ary))
{
    $smarty->assign('num', $num);
    $smarty->display('ch10/05.tpl.htm', $num);
}
else
{
    echo '錯誤的編號';
}
?>
