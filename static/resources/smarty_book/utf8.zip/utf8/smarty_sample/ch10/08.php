<?php
include ('main.php');

$smarty = new Template();

$smarty->caching = TRUE;

$smarty->assign('create_time', date("Y-m-d H:i:s"));

$num = $_GET["num"];
$num_ary = array ("1", "2", "3", "4", "5");

if (in_array($num, $num_ary))
{
    if (!$smarty->is_cached('ch10/08.tpl.htm', $num))
    {
        //做一些複雜且耗時的工作
        do_complex_work();

        $smarty->assign('num', $num);
    }
    
    $smarty->display('ch10/08.tpl.htm', $num);
}
else
{
    echo '錯誤的編號';
}

function do_complex_work()
{
    for ($i = 0; $i < 200000; $i ++) $temp = rand();
}
?>
