<?php
include ('main.php');

$smarty = new Template();

$smarty->caching = TRUE;

$smarty->assign('create_time', date("Y-m-d H:i:s"));

$smarty->display('ch10/01.tpl.htm');
?>