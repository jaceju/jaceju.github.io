<?php
include ('main.php');

$smarty = new Template();

$smarty->display('ch08/01.tpl.htm');
?>
