<?php
include ('main.php');

$smarty = new Template();

$smarty->assign('num', 1000);

$smarty->display('ch08/03.tpl.htm');
?>
