<?php
include ('main.php');

$smarty = new Template();

$smarty->assign('num1', 1000);
$smarty->assign('num2', 2000);

$smarty->display('ch08/04.tpl.htm');
?>
