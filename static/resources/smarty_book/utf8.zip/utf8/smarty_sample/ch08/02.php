<?php
include ('main.php');

$smarty = new Template();

$smarty->assign('header_page', 'ch08/02_header.tpl.htm');
$smarty->assign('footer_page', 'ch08/02_footer.tpl.htm');

$smarty->display('ch08/02.tpl.htm');
?>
