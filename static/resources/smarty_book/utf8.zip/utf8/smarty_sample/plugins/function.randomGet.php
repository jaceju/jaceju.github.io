<?php
function smarty_function_randomGet($params, &$smarty)
{
    $result = '';
    if (isset($params['value']) &&
        is_array($params['value']))
    {
        $result = 
            $params['value'][array_rand($params['value'])];
    }
    return $result;
}
?>