<?php
function smarty_block_testRepeat($params, $content, &$smarty, &$repeat)
{
  static $count;

  if (!isset($content)) // 第一次呼叫
  {
    if (!isset($params['count']))
      $smarty->trigger_error('count needed');
    $count = $params['count'];
  }
  else
  {
    $count --;
  }

  $repeat = (bool) $count > 0;
  return $content;
}
?>