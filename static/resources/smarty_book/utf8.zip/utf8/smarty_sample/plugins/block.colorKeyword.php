<?php
function smarty_block_colorKeyword($params, $content, &$smarty, &$repeat)
{
    $color_keyword = '';
    if (isset($params['keyword']))
        $color_keyword = 
            '<font color="red">' . 
            $params['keyword'] .
            '</font>';
    if (isset($content))
        return str_replace($params['keyword'], 
        $color_keyword, $content);
}
?>