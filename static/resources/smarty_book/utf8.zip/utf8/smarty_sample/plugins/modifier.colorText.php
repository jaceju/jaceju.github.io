<?php
function smarty_modifier_colorText($value, $color = 'black')
{
    return "<font color=\"$color\">" . $value . "</font>";
}
?>