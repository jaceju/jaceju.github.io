<?php
function smarty_insert_realtimeNews($params, &$smarty)
{
    $head_line = array (
        '頭條新聞 1',
        '頭條新聞 2',
        '頭條新聞 3',
        '頭條新聞 4',
        '頭條新聞 5',
    );

    return $head_line[array_rand($head_line)];
}
?>