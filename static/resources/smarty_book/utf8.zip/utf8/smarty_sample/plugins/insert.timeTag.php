<?php
function smarty_insert_timeTag($params, &$smarty)
{
    return isset($params['output'])
        ? $params['output']
        : date('Y-m-d H:i:s');
}
?>