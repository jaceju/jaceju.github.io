<html>
<head>
<title>Sample 1</title>
</head>
<body>
<p style="color: blue;">
<?php
$num1 = 1000;
$num2 = 2000;
$num3 = $num1 + $num2;
echo $num3;
?>
</p>
</body>
</html>
