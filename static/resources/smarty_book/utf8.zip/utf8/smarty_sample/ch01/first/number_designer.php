<html>
<head>
<title>Sample 1</title>
</head>
<body>
<font color="red">
<?php
$num1 = 1000;
$num2 = 2000;
$num3 = $num1 + $num2;
echo $num3;
?>
</font>
</body>
</html>
