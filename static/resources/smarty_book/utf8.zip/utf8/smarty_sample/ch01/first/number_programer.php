<html>
<head>
<title>Sample 1</title>
</head>
<body>
<font color="blue">
<?php
$num1 = 1000;
$num2 = 2000;
$num3 = $num1 * $num2; // 兩數相加改為兩數相乘
echo $num3;
?>
</font>
</body>
</html>
