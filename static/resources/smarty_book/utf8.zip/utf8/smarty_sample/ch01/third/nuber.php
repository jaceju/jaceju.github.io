<html>
<head>
<title>Sample 1</title>
</head>
<body>
<p style="color: blue;">3000</p>
<!-- 原有已套用程式的部份不小心被刪除了 -->
</body>
</html>
