<?php
$num1 = 1000;
$num2 = 2000;
$num3 = $num1 + $num2;
$num3_formated = number_format($num3);

include ('number_dirty.htm');
?>
