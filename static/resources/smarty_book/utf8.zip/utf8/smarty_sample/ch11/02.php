<?php
include ('main.php');

$smarty = new Template();

$smarty->assign('my_array', 
    array (
        '元素 1',
        '元素 2',
        '元素 3',
        '元素 4',
        '元素 5',
    )
);

$smarty->display('ch11/02.tpl.htm');
?>
