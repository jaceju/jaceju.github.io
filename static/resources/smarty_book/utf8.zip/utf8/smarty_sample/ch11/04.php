<?php
include ('main.php');

$smarty = new Template();

$smarty->assign('keyword', '關鍵字');

$smarty->display('ch11/04.tpl.htm');
?>
