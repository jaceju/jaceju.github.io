<?php
include ('main.php');

$smarty = new Template();

$smarty->assign('value', 'colorText');

$smarty->display('ch11/01.tpl.htm');
?>
