<?php
include ('main.php');

$smarty = new Template();

$smarty->caching = TRUE;

if (!$smarty->is_cached('ch11/06.tpl.htm'))
{
    $news = array (
        '一般新聞 1',
        '一般新聞 2',
        '一般新聞 3',
        '一般新聞 4',
        '一般新聞 5',
    );

    $smarty->assign('news', $news);
}

$smarty->display('ch11/07.tpl.htm');
?>
