<?php
include ('main.php');

$smarty = new Template();

$smarty->assign('create_time', date('Y-m-d H:i:s'));

$smarty->caching = TRUE;

$smarty->display('ch11/05.tpl.htm');
?>
