<?php
include ('main.php');

$smarty = new Template();

$content = <<<CONTENT
這裡是第一段。

到第二段了，
這裡是第二段的折行。

換成第三段了。
CONTENT;

$smarty->assign('content', $content);

$smarty->display('ch11/06.tpl.htm');
?>
