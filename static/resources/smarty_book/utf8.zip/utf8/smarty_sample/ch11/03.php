<?php
include ('main.php');

$smarty = new Template();

$smarty->display('ch11/03.tpl.htm');
?>
