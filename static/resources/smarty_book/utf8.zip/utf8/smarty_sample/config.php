<?php
define ('APP_REAL_PATH', str_replace('\\', '/', dirname(__FILE__))); // 定義網站實體路徑