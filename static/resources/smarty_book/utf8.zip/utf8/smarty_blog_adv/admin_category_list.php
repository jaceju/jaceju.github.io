<?php
include ('admin_main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 取得分類列表
//===============================================
if (isset($_GET['keyword']) && $_GET['keyword'] != '')
{
    $sql = "SELECT * FROM WHERE title LIKE ? category ORDER BY category_id";
    $category_list = &$db->getAll($sql, array ($_GET['keyword']));
}
else
{
    $sql = "SELECT * FROM category ORDER BY category_id";
    $category_list = &$db->getAll($sql);
}

if (DB::isError($category_list))
{
  header("Content-Type: text/plain; charset=big5");
  die ($category_list->getDebugInfo());
}

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('category_list', $category_list);

$smarty->assign(
  'admin_page_content_file',
  'admin_category_list.tpl.htm'
);

//===============================================
// 顯示頁面
//===============================================
$smarty->display('admin_main.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>