<?php
include ('admin_main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 如果為 POSTBACK ，則修改文章內容
//===============================================
if (isset($_POST['postback']) && 'true' == $_POST['postback'])
{
  $sql_handle = &$db->prepare(
    "UPDATE article SET " . 
    "title = ?, " .
    "author = ?, " .
    "category_id = ?, " .
    "description = ?, " .
    "content = ?, " .
    "lastBuildDate = ? " .
    "WHERE article_id = ?"
  );

  $result = &$db->execute($sql_handle,
    array (
      $_POST['title'],
      BLOG_AUTHOR,
      $_POST['category_id'],
      $_POST['description'],
      $_POST['content'],
      date("Y-m-d H:i:s"),
      $_POST['article_id'],
    )
  );

  if (DB::isError($result))
  {
    header("Content-Type: text/plain; charset=big5");
    die ($result->getMessage());
  }

  $db->disconnect();

  header('Location: admin_article_list.php');

  exit;
}

//===============================================
// 取得下拉式選單所需要的分類資訊
//===============================================
$category_list_output = &$db->getCol(
  "SELECT title FROM category ORDER BY category_id"
);

$category_list_values = &$db->getCol(
  "SELECT category_id FROM category ORDER BY category_id"
);

//===============================================
// 取得文章內容
//===============================================
$article_detail = &$db->getRow(
  "SELECT * FROM article WHERE article_id = ?",
  array ($_GET['aid'])
);

if (DB::isError($article_detail))
{
  die ($article_detail->getMessage());
}

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('category_list_output', $category_list_output);

$smarty->assign('category_list_values', $category_list_values);

$smarty->assign('article_detail', $article_detail);

$smarty->assign('page_title', '修改文章');

$smarty->assign(
  'admin_page_content_file',
  'admin_article_edit.tpl.htm'
);

//===============================================
// 顯示頁面
//===============================================
$smarty->display('admin_main.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>
