<?php
include ('main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 取得文章列表
//===============================================
$article_list_object = new ArticleList($db);

$article_list = &$article_list_object->getList();

if (DB::isError($article_list))
{
  header("Content-Type: text/plain; charset=big5");
  die ($article_list->getMessage());
}

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('article_list', $article_list);

//===============================================
// 載入邊欄程式
//===============================================
include ('sidebar.php');

$smarty->assign(
  'page_content_file',
  'article_list.tpl.htm'
);

//===============================================
// 顯示頁面
//===============================================
$smarty->display('main.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>