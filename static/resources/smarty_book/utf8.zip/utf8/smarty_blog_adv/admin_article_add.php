<?php
include ('admin_main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 如果為 POSTBACK ，則新增文章內容
//===============================================
if (isset($_POST['postback']) && 'true' == $_POST['postback'])
{
  $sql_handle = &$db->prepare(
    "INSERT INTO article " . 
    "(title, author, category_id, " .
    "description, content, pubDate)" .
    "VALUES (?, ?, ?, ?, ?, ?)"
  );

  $result = &$db->execute($sql_handle,
    array (
      $_POST['title'],
      BLOG_AUTHOR,
      $_POST['category_id'],
      $_POST['description'],
      $_POST['content'],
      date("Y-m-d H:i:s")
    )
  );

  if (DB::isError($result))
  {
    header("Content-Type: text/plain; charset=big5");
    die ($result->getMessage());
  }

  $db->disconnect();

  header('Location: admin_article_list.php');

  exit;
}

//===============================================
// 取得下拉式選單所需要的分類資訊
//===============================================
$category_list_output = &$db->getCol(
  "SELECT title FROM category ORDER BY category_id"
);

$category_list_values = &$db->getCol(
  "SELECT category_id FROM category ORDER BY category_id"
);

//===============================================
// 指定一個空白的文章內容
//===============================================
$article_detail = array (
  'article_id'  => 0,
  'title'       => '',
  'category_id' => 0,
  'description' => '',
  'content'     => '',
  'description' => ''
);

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('category_list_output', $category_list_output);

$smarty->assign('category_list_values', $category_list_values);

$smarty->assign('article_detail', $article_detail);

$smarty->assign('page_title', '新增文章');

$smarty->assign(
  'admin_page_content_file',
  'admin_article_edit.tpl.htm'
);

//===============================================
// 顯示頁面
//===============================================
$smarty->display('admin_main.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>