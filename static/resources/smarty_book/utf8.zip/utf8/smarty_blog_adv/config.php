<?php
// 定義資料庫類型
define ('DB_TYPE', 'mysql');
// 定義資料庫來源
define ('DB_HOST', 'localhost');
// 定義資料庫帳號
define ('DB_USER', 'www');
// 定義資料庫密碼
define ('DB_PASS', '123456');
// 定義資料庫名稱
define ('DB_NAME', 'smarty_blog');
// 用戶端編碼 (big5 或 utf8)
define ('DB_CHAR_SET', 'utf8');

// 定義資料庫連線字串
define ('DB_DSN',  DB_TYPE
    . '://' . DB_USER
    . ':' .   DB_PASS
    . '@' .   DB_HOST
    . '/' .   DB_NAME);

// 定義網站實體路徑
define ('APP_REAL_PATH', str_replace('\\', '/', dirname(__FILE__)));

// 定義網站相對路徑
define ('RELATIVE_PATH', '/smarty_blog_adv');

// 定義 BLOG 名稱
define ('BLOG_TITLE',  'Smarty Blog');
// 定義 BLOG 作者名稱
define ('BLOG_AUTHOR', 'jaceju');
// 定義 BLOG 作者密碼
define ('BLOG_PASSWD', '123456');