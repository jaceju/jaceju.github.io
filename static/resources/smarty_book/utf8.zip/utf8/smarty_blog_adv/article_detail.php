<?php
include ('main.php');

//===============================================
// 建立資料庫連結
//===============================================
$db = &getDB(DB_DSN);

$db->setFetchMode(DB_FETCHMODE_ASSOC);

//===============================================
// 如果為 POSTBACK ，則新增使用者輸入的評論內容
//===============================================
if (isset($_POST['postback']) && 'true' == $_POST['postback'])
{
  // 新增使用者輸入的評論內容  
  $sql_handle = &$db->prepare(
    "INSERT INTO comment " . 
    "(article_id, visitorname, comment, createDate) " .
    "VALUES (?, ?, ?, ?)"
  );

  $result = &$db->execute($sql_handle,
    array (
      $_POST['article_id'],
      $_POST['visitorname'],
      $_POST['comment'],
      date("Y-m-d H:i:s"),
    )
  );

  // 如果無法成功執行，則顯示錯誤訊息
  if (DB::isError($result))
  {
    header("Content-Type: text/plain; charset=big5");
    die ($result->getMessage());
  }

  $db->disconnect();

  // 導回原頁，防止使用者按下重新整理
  header(
    'Location: article_detail.php?aid='
    . $_POST['article_id']
  );

  exit;
}

//===============================================
// 取得文章內容
//===============================================
$article_detail = &$db->getRow(
  "SELECT * FROM article WHERE article_id = ?",
  array ($_GET['aid'])
);

if (DB::isError($article_detail))
{
  header("Content-Type: text/plain; charset=big5");
  die ($article_detail->getMessage());
}

//===============================================
// 取得該文章的所有評論
//===============================================
$comment_list = &$db->getAll(
  "SELECT * FROM comment WHERE article_id = ?",
  array ($_GET['aid'])
);

if (DB::isError($comment_list))
{
  header("Content-Type: text/plain; charset=big5");
  die ($comment_list->getMessage());
}

//===============================================
// 樣版處理
//===============================================
$smarty = new Template();

$smarty->assign('article_detail', $article_detail);

$smarty->assign('comment_list', $comment_list);

//===============================================
// 載入邊欄程式
//===============================================
include ('sidebar.php');

$smarty->assign(
  'page_content_file',
  'article_detail.tpl.htm'
);

//===============================================
// 顯示頁面
//===============================================
$smarty->display('main.tpl.htm');

//===============================================
// 結束程式，釋放資料庫連結
//===============================================
$db->disconnect();
?>