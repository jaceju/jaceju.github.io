<?php

define('APP_REAL_PATH', str_replace('\\', '/', dirname(__FILE__)));
define('APP_NAME', 'WebMVC 留言版');
define('APP_STORAGE', APP_REAL_PATH . '/database/guestbook.txt');