<?php

// 載入設定
require_once 'config.php';

// 取得所有留言
$messages = (file_exists(APP_STORAGE))
          ? unserialize(file_get_contents(APP_STORAGE))
          : array ();

// 組合 XML
$xml = '';
$xml .= '<' . '?xml version="1.0" encoding="utf-8"?' . '>' . "\n";
$xml .= '<rss version="2.0">' . "\n";
$xml .= '<channel>' . "\n";
$xml .= '<title>TEST</title>' . "\n";
$xml .= '<description>TEST</description>' . "\n";
foreach ($messages as $message)
{
    $xml .= '<item>' . "\n";
    $xml .= '<title>' . $message['title'] . '</title>' . "\n";
    $xml .= '<description>' . $message['body'] . '</description>' . "\n";
    $xml .= '</item>' . "\n";
}
$xml .= '</channel>' . "\n";
$xml .= '</rss>';

// 輸出 XML
header('Content-Type: text/xml; charset=utf-8');

echo $xml;