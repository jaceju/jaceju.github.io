<?php

// 載入設定
require_once 'config.php';

// 取得表單變數
$title = $_POST['title'];
$author = $_POST['author'];
$body = $_POST['body'];

// 取得所有留言
$messages = (file_exists(APP_STORAGE))
          ? unserialize(file_get_contents(APP_STORAGE))
          : array ();

// 在所有留言的最後加上一筆
$messages[] = array (
    'id'     => count($messages) + 1,
    'title'  => $title,
    'author' => $author,
    'body'   => $body,
);

// 將所有留言寫回檔案
file_put_contents(APP_STORAGE, serialize($messages));

// 導回列表頁
header('Location: ./');
